// DefaultName.h

#ifndef ZIP7_INC_DEFAULT_NAME_H
#define ZIP7_INC_DEFAULT_NAME_H

#include "../../../Common/MyString.h"

UString GetDefaultName2(const UString &fileName,
    const UString &extension, const UString &addSubExtension);

#endif
